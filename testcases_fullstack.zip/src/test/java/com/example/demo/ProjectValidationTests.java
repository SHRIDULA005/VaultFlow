package com.example.demo;

import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.data.domain.*;
import java.lang.reflect.*;
import java.util.*;

/**
 * VaultFlow (Transaction & Ledger Orchestrator) — Backend Validation Test Suite
 *
 * Domain: Financial transaction management, ledger orchestration, audit trails
 * Roles: ADMIN, TREASURER, AUDITOR, USER
 * Protocol: Zero direct imports in reflection tests. All class access via
 * Class.forName().
 * Every test carries a SRS_REF comment forming the Requirements Traceability
 * Matrix.
 */
@Listeners(TestResultListener.class)
public class ProjectValidationTests {

    // =========================================================================
    // CATEGORY 1: Package & Layer Architecture (t1–t5)
    // =========================================================================

    @Test
    public void t01_verifyTransactionControllerExists() throws Exception {
        // SRS_REF: REQ-CTRL-01 — TransactionController routes all financial movement
        // requests
        // (/api/transactions/**) and initiates the orchestration sequence.
        Assert.assertNotNull(Class.forName("com.example.demo.controller.TransactionController"),
                "TransactionController must exist to handle entry points for financial operations");
    }

    @Test
    public void t02_verifyLedgerServiceExists() throws Exception {
        // SRS_REF: REQ-SVC-01 — LedgerService encapsulates business logic for ledger
        // reconciliation, integrity checks, and historical balancing.
        Assert.assertNotNull(Class.forName("com.example.demo.service.LedgerService"),
                "LedgerService must exist to separate balancing logic from HTTP routing");
    }

    @Test
    public void t03_verifyAccountRepositoryExists() throws Exception {
        // SRS_REF: REQ-REPO-01 — AccountRepository provides Spring Data JPA access
        // for Account entity, supporting atomic balance updates.
        Assert.assertNotNull(Class.forName("com.example.demo.repository.AccountRepository"),
                "AccountRepository must exist as the persistence interface for financial accounts");
    }

    @Test
    public void t04_verifyTransactionEntityExists() throws Exception {
        // SRS_REF: REQ-ENT-01 — Transaction is the persistent model mapped to
        // tbl_transactions,
        // tracking audit IDs, amounts, and source/target accounts.
        Assert.assertNotNull(Class.forName("com.example.demo.model.Transaction"),
                "Transaction entity must exist as the core ledger entry model");
    }

    @Test
    public void t05_verifySecurityConfigExists() throws Exception {
        // SRS_REF: REQ-SEC-01 — SecurityConfig defines authentication filters,
        // role-based
        // access control (TREASURER, AUDITOR), and stateless filter topology.
        Assert.assertNotNull(Class.forName("com.example.demo.config.SecurityConfig"),
                "SecurityConfig must exist to enforce financial-grade authorization rules");
    }

    // =========================================================================
    // CATEGORY 2: Controller Layer Validation (t6–t18)
    // =========================================================================

    @Test
    public void t06_controllerRestControllerAnnotation() throws Exception {
        // SRS_REF: REQ-CTRL-02 — All VaultFlow controllers must be @RestController
        // for consistent JSON serialization of financial data.
        Class<?> clazz = Class.forName("com.example.demo.controller.TransactionController");
        Assert.assertTrue(clazz.isAnnotationPresent(RestController.class),
                "@RestController is required for JSON response serialization");
    }

    @Test
    public void t07_transactionControllerRequestMapping() throws Exception {
        // SRS_REF: REQ-CTRL-03 — Transaction endpoints must be grouped under
        // /api/transactions
        // to align with the global security filter for financial operations.
        Class<?> clazz = Class.forName("com.example.demo.controller.TransactionController");
        String path = clazz.getAnnotation(RequestMapping.class).value()[0];
        Assert.assertEquals(path, "/api/transactions",
                "TransactionController base path must be /api/transactions");
    }

    @Test
    public void t08_transactionSavePostMapping() throws Exception {
        // SRS_REF: REQ-CTRL-04 — Transaction creation must use @PostMapping
        // to satisfy REST conventions for resource initiation.
        Class<?> clazz = Class.forName("com.example.demo.controller.TransactionController");
        Method m = clazz.getDeclaredMethod("createTransaction",
                Class.forName("com.example.demo.dto.TransactionDTO"));
        Assert.assertTrue(m.isAnnotationPresent(PostMapping.class),
                "createTransaction must use @PostMapping");
    }

    @Test
    public void t09_transactionRequestBodyValidation() throws Exception {
        // SRS_REF: REQ-CTRL-05 — Incoming transaction payloads must carry @RequestBody
        // for deserialization into the domain DTO.
        Class<?> clazz = Class.forName("com.example.demo.controller.TransactionController");
        Method m = clazz.getDeclaredMethod("createTransaction",
                Class.forName("com.example.demo.dto.TransactionDTO"));
        Parameter param = m.getParameters()[0];
        Assert.assertTrue(param.isAnnotationPresent(RequestBody.class),
                "@RequestBody is required for transaction JSON deserialization");
    }

    @Test
    public void t10_ledgerListGetMapping() throws Exception {
        // SRS_REF: REQ-CTRL-06 — Ledger retrieval must use @GetMapping to support
        // read-only historical audit browsing.
        Class<?> clazz = Class.forName("com.example.demo.controller.LedgerController");
        Method m = clazz.getDeclaredMethod("getAllLedgers", Pageable.class);
        Assert.assertTrue(m.isAnnotationPresent(GetMapping.class),
                "getAllLedgers must use @GetMapping for RESTful read operations");
    }

    @Test
    public void t11_accountUpdatePutMapping() throws Exception {
        // SRS_REF: REQ-CTRL-07 — Account modifications must use @PutMapping with /{id}
        // to target a specific financial account for reconciliation.
        Class<?> clazz = Class.forName("com.example.demo.controller.AccountController");
        Method m = clazz.getDeclaredMethod("updateAccount", Long.class,
                Class.forName("com.example.demo.dto.AccountDTO"));
        Assert.assertTrue(m.isAnnotationPresent(PutMapping.class),
                "updateAccount must use @PutMapping with /{id} for idempotent updates");
        String path = m.getAnnotation(PutMapping.class).value()[0];
        Assert.assertEquals(path, "/{id}", "Update path must include ID variable");
    }

    @Test
    public void t12_transactionDeleteMapping() throws Exception {
        // SRS_REF: REQ-CTRL-08 — Transaction reversal/deletion must use @DeleteMapping
        // and return a message confirming "Transaction reversed successfully."
        Class<?> clazz = Class.forName("com.example.demo.controller.TransactionController");
        Method m = clazz.getDeclaredMethod("reverseTransaction", Long.class);
        Assert.assertTrue(m.isAnnotationPresent(DeleteMapping.class),
                "reverseTransaction must use @DeleteMapping for resource removal");

        // Body verification via mock
        Object controller = clazz.getDeclaredConstructor().newInstance();
        Field serviceField = clazz.getDeclaredField("transactionService");
        serviceField.setAccessible(true);
        // Mocking class-based service via reflection to bypass Proxy interface
        // requirement
        Class<?> mockitoClass = Class.forName("org.mockito.Mockito");
        Object mockService = mockitoClass.getMethod("mock", Class.class)
                .invoke(null, Class.forName("com.example.demo.service.TransactionService"));
        serviceField.set(controller, mockService);
        ResponseEntity<?> resp = (ResponseEntity<?>) m.invoke(controller, 1L);
        Assert.assertEquals(resp.getBody(), "Transaction reversed successfully.",
                "Response body must match expected reversal confirmation string");
    }

    @Test
    public void t13_restrictedActionPreAuthorize() throws Exception {
        // SRS_REF: REQ-SEC-02 — High-value transactions must be restricted to TREASURER
        // to prevent unauthorized funds movement.
        Class<?> clazz = Class.forName("com.example.demo.controller.TransactionController");
        Method m = clazz.getDeclaredMethod("createTransaction",
                Class.forName("com.example.demo.dto.TransactionDTO"));
        Assert.assertTrue(m.isAnnotationPresent(PreAuthorize.class),
                "@PreAuthorize is required for fund movements");
        String expression = m.getAnnotation(PreAuthorize.class).value();
        Assert.assertTrue(expression.contains("TREASURER") || expression.contains("ADMIN"),
                "Role expression must contain TREASURER for transaction creation");
    }

    @Test
    public void t14_auditorPermissions() throws Exception {
        // SRS_REF: REQ-SEC-03 — Audit logs must be accessible by AUDITOR role
        // to allow compliance monitoring without modification rights.
        Class<?> clazz = Class.forName("com.example.demo.controller.LedgerController");
        Method m = clazz.getDeclaredMethod("getAllLedgers", Pageable.class);
        Assert.assertTrue(m.isAnnotationPresent(PreAuthorize.class),
                "Ledger access must be secured for auditors");
        String expression = m.getAnnotation(PreAuthorize.class).value();
        Assert.assertTrue(expression.contains("AUDITOR"),
                "AUDITOR role must be permitted to browse ledger history");
    }

    @Test
    public void t15_responseEntityUsage() throws Exception {
        // SRS_REF: REQ-CTRL-09 — All controller methods should return ResponseEntity<?>
        // to provide explicit control over HTTP status codes (e.g., 201 Created).
        Class<?> clazz = Class.forName("com.example.demo.controller.TransactionController");
        Method m = clazz.getDeclaredMethod("createTransaction",
                Class.forName("com.example.demo.dto.TransactionDTO"));
        Assert.assertEquals(m.getReturnType(), ResponseEntity.class,
                "Methods must return ResponseEntity for status code management");
    }

    @Test
    public void t16_corsConfigPresent() throws Exception {
        // SRS_REF: REQ-CORS-01 — System must permit CORS from the VaultFlow frontend
        // at localhost:3000 to allow transaction orchestration.
        Class<?> clazz = Class.forName("com.example.demo.config.SecurityConfig");
        boolean hasCors = Arrays.stream(clazz.getDeclaredMethods()).anyMatch(m -> m.getName().contains("cors"));
        Assert.assertTrue(hasCors, "SecurityConfig must define CORS policy");
    }

    @Test
    public void t17_validAnnotationUsage() throws Exception {
        // SRS_REF: REQ-VAL-01 — @Valid must be applied to TransactionDTO to trigger
        // threshold and balance-check validation.
        Class<?> clazz = Class.forName("com.example.demo.controller.TransactionController");
        Method m = clazz.getDeclaredMethod("createTransaction",
                Class.forName("com.example.demo.dto.TransactionDTO"));
        Parameter param = m.getParameters()[0];
        boolean hasValid = Arrays.stream(param.getAnnotations())
                .anyMatch(a -> a.annotationType().getSimpleName().equals("Valid"));
        Assert.assertTrue(hasValid, "@Valid required on transaction body");
    }

    @Test
    public void t18_pathVariableUsage() throws Exception {
        // SRS_REF: REQ-CTRL-10 — Single transaction detail lookup must use
        // @PathVariable
        // for RESTful resource identification.
        Class<?> clazz = Class.forName("com.example.demo.controller.TransactionController");
        Method m = clazz.getDeclaredMethod("getTransactionById", Long.class);
        Assert.assertTrue(m.getParameters()[0].isAnnotationPresent(PathVariable.class),
                "@PathVariable required for ID parsing");
    }

    // =========================================================================
    // CATEGORY 3: Repository Layer (t19–t20)
    // =========================================================================

    @Test
    public void t19_repositoryIsInterface() throws Exception {
        // SRS_REF: REQ-REPO-02 — All repositories must be interfaces for Spring Data
        // JPA proxying.
        Class<?> clazz = Class.forName("com.example.demo.repository.TransactionRepository");
        Assert.assertTrue(clazz.isInterface(), "Repositories must be interfaces");
    }

    @Test
    public void t20_repositoryExtendsJpa() throws Exception {
        // SRS_REF: REQ-REPO-03 — Repository must extend JpaRepository to inherit
        // transactional CRUD.
        Class<?> clazz = Class.forName("com.example.demo.repository.TransactionRepository");
        Assert.assertTrue(org.springframework.data.jpa.repository.JpaRepository.class.isAssignableFrom(clazz),
                "Repositories must extend JpaRepository");
    }

    // =========================================================================
    // CATEGORY 4: Exception Handling (t21–t23)
    // =========================================================================

    @Test
    public void t21_globalExceptionHandler() throws Exception {
        // SRS_REF: REQ-EX-01 — A global exception handler must intercept
        // finance-related errors.
        Class<?> clazz = Class.forName("com.example.demo.exception.GlobalExceptionHandler");
        Assert.assertTrue(clazz.isAnnotationPresent(RestControllerAdvice.class),
                "@RestControllerAdvice required for global interceptors");
    }

    @Test
    public void t22_insufficientFundsMapping() throws Exception {
        // SRS_REF: REQ-EX-02 — InsufficientFundsException must return HTTP 400 Bad
        // Request
        // with a descriptive message preventing overdraft.
        Class<?> handlerClass = Class.forName("com.example.demo.exception.GlobalExceptionHandler");
        Class<?> exClass = Class.forName("com.example.demo.exception.InsufficientFundsException");
        Method m = handlerClass.getDeclaredMethod("handleInsufficientFunds", exClass);
        Object handler = handlerClass.getConstructor().newInstance();
        Object ex = exClass.getConstructor(String.class).newInstance("Balance below zero");
        ResponseEntity<?> resp = (ResponseEntity<?>) m.invoke(handler, ex);
        Assert.assertEquals(resp.getStatusCode(), HttpStatus.BAD_REQUEST, "Should map to 400");
    }

    @Test
    public void t23_unauthorizedExceptionHandling() throws Exception {
        // SRS_REF: REQ-EX-03 — Security violations by non-TREASURER actors must return
        // HTTP 403.
        Class<?> handlerClass = Class.forName("com.example.demo.exception.GlobalExceptionHandler");
        Class<?> exClass = Class.forName("com.example.demo.exception.UnauthorizedException");
        Method m = handlerClass.getDeclaredMethod("handleUnauthorized", exClass);
        Object handler = handlerClass.getConstructor().newInstance();
        Object ex = exClass.getConstructor(String.class).newInstance("Access Denied");
        ResponseEntity<?> resp = (ResponseEntity<?>) m.invoke(handler, ex);
        Assert.assertEquals(resp.getStatusCode(), HttpStatus.FORBIDDEN, "Should map to 403");
    }

    // =========================================================================
    // CATEGORY 5: JWT Security Layer (t24–t26)
    // =========================================================================

    @Test
    public void t24_jwtKeyIsPrivate() throws Exception {
        // SRS_REF: REQ-JWT-01 — JWT secret key must be private to prevent orchestration
        // hijacking.
        Class<?> clazz = Class.forName("com.example.demo.security.JwtUtil");
        Field f = clazz.getDeclaredField("SECRET_KEY");
        Assert.assertTrue(Modifier.isPrivate(f.getModifiers()), "SECRET_KEY must be private");
    }

    @Test
    public void t25_jwtGenerateToken() throws Exception {
        // SRS_REF: REQ-JWT-02 — generateToken must return a signed String payload for
        // the client.
        Class<?> clazz = Class.forName("com.example.demo.security.JwtUtil");
        Method m = clazz.getDeclaredMethod("generateToken",
                org.springframework.security.core.userdetails.UserDetails.class);
        Assert.assertEquals(m.getReturnType(), String.class, "Should return String token");
    }

    @Test
    public void t26_jwtValidateToken() throws Exception {
        // SRS_REF: REQ-JWT-03 — validateToken must return Boolean for filter chain
        // decisions.
        Class<?> clazz = Class.forName("com.example.demo.security.JwtUtil");
        Method m = clazz.getDeclaredMethod("validateToken", String.class);
        Assert.assertEquals(m.getReturnType(), Boolean.class, "Should return Boolean validation");
    }

    // =========================================================================
    // CATEGORY 6: Entity & Database Mapping (t27–t28)
    // =========================================================================

    @Test
    public void t27_transactionTableName() throws Exception {
        // SRS_REF: REQ-DB-01 — Transaction entity must map to tbl_transactions for DB
        // alignment.
        Class<?> clazz = Class.forName("com.example.demo.model.Transaction");
        String name = clazz.getAnnotation(jakarta.persistence.Table.class).name();
        Assert.assertEquals(name, "tbl_transactions", "Should map to tbl_transactions");
    }

    @Test
    public void t28_transactionColumnConstraints() throws Exception {
        // SRS_REF: REQ-DB-02 — amount and referenceId must carry nullable=false
        // constraints.
        Class<?> clazz = Class.forName("com.example.demo.model.Transaction");
        Field f = clazz.getDeclaredField("amount");
        Assert.assertFalse(f.getAnnotation(jakarta.persistence.Column.class).nullable(), "Amount cannot be null");
    }

    // =========================================================================
    // CATEGORY 7: Security Filter Chain (t29–t30)
    // =========================================================================

    @Test
    public void t29_passwordEncoderBean() throws Exception {
        // SRS_REF: REQ-SEC-04 — SecurityConfig must expose a BCryptPasswordEncoder
        // @Bean.
        Class<?> clazz = Class.forName("com.example.demo.config.SecurityConfig");
        Assert.assertTrue(
                clazz.getDeclaredMethod("passwordEncoder")
                        .isAnnotationPresent(org.springframework.context.annotation.Bean.class),
                "passwordEncoder @Bean required");
    }

    @Test
    public void t30_securityFilterChainBean() throws Exception {
        // SRS_REF: REQ-SEC-05 — SecurityFilterChain must explicitly restrict
        // /api/transactions.
        Class<?> clazz = Class.forName("com.example.demo.config.SecurityConfig");
        Assert.assertTrue(clazz.getDeclaredMethod("securityFilterChain",
                org.springframework.security.config.annotation.web.builders.HttpSecurity.class)
                .isAnnotationPresent(org.springframework.context.annotation.Bean.class),
                "securityFilterChain @Bean required");
    }
}